package org.lanqiao.exception;

public class TriangleException extends RuntimeException{

    private static final long serialVersionUID = 1L;

    public TriangleException(String message){
        super(message);
    }

}